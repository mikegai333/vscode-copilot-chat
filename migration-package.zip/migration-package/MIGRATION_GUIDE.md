# 代码补全模块迁移指南

## 🎯 关于鉴权代码的建议

### ✅ 推荐方案：完全移除GitHub鉴权

基于你已经实现的 `allowAnonymous` 机制，**强烈建议完全删除所有GitHub OAuth相关的鉴权代码**。

### 为什么要删除？

1. **你已经有更好的方案** - `allowAnonymous` 机制已经完美支持自定义API
2. **代码更简洁** - 减少70%以上的鉴权相关代码
3. **没有外部依赖** - 不依赖GitHub服务
4. **更易维护** - 不需要处理token刷新、过期、配额等复杂逻辑
5. **更适合企业场景** - 企业内部部署不需要GitHub账号

### 需要删除的文件和代码

#### 完全删除的文件夹：
```
❌ platform/authentication/ (整个文件夹)
```

#### 需要修改的文件：

**1. `platform/nesFetch/node/completionsFetchServiceImpl.ts`**

删除第124-136行的配额检查逻辑：
```typescript
// ❌ 删除这段代码
if (this.authService.copilotToken) {
    if (response.status === 200 && this.authService.copilotToken.isFreeUser && this.authService.copilotToken.isChatQuotaExceeded) {
        this.authService.resetCopilotToken();
    }
    if (response.status !== 200 && response.status === 402) {
        this.authService.resetCopilotToken(response.status);
        return Result.error<CompletionsFetchFailure>({ kind: 'quota-exceeded' });
    }
}
```

修改构造函数，移除 `IAuthenticationService` 依赖：
```typescript
// ❌ 删除
@IAuthenticationService private authService: IAuthenticationService,

// ✅ 只保留
@IFetcherService private fetcherService: IFetcherService,
```

**2. `extension/completions/vscode-node/completionsProvider.ts`**

简化第88-108行：
```typescript
// ❌ 删除原有逻辑
const allowAnonymous = this.configService.getConfig(ConfigKey.Internal.CompletionsProviderAllowAnonymous);
if (allowAnonymous) {
    // ...
}
if (!secretKey) {
    secretKey = (await this.authService.getCopilotToken()).token;
}

// ✅ 改为
const url = this.configService.getConfig('yourExtension.completions.apiUrl');
const secretKey = this.configService.getConfig('yourExtension.completions.apiKey');
const modelName = this.configService.getConfig('yourExtension.completions.modelName');

if (!url || !secretKey) {
    throw new Error('请先配置API地址和密钥');
}
```

删除构造函数中的 `IAuthenticationService` 依赖：
```typescript
// ❌ 删除
@IAuthenticationService private authService: IAuthenticationService,
```

**3. `extension/xtab/node/xtabProvider.ts`**

简化第1278-1309行的 `getEndpoint` 方法：
```typescript
private getEndpoint(configuredModelName: string | undefined): { endpoint: ChatEndpoint; secretKey?: string } {
    const url = this.configService.getConfig('yourExtension.inlineEdits.apiUrl');
    const apiKey = this.configService.getConfig('yourExtension.inlineEdits.apiKey');

    if (!url || !apiKey) {
        throw new Error('请先配置智能编辑API地址和密钥');
    }

    return {
        endpoint: this.instaService.createInstance(XtabEndpoint, url, apiKey, configuredModelName),
        secretKey: apiKey
    };
}
```

**4. `extension/inlineEdits/vscode-node/inlineEditProviderFeature.ts`**

简化第55-76行的启用逻辑：
```typescript
public readonly inlineEditsEnabled = derived(this, (reader) => {
    const apiUrl = this._configurationService.getConfig('yourExtension.inlineEdits.apiUrl');
    const apiKey = this._configurationService.getConfig('yourExtension.inlineEdits.apiKey');
    return !!(apiUrl && apiKey);
});
```

删除第52行的 `_copilotToken` observable：
```typescript
// ❌ 删除
private readonly _copilotToken = observableFromEvent(this, this._authenticationService.onDidAuthenticationChange, () => this._authenticationService.copilotToken);
```

删除构造函数中的 `IAuthenticationService` 依赖：
```typescript
// ❌ 删除
@IAuthenticationService private readonly _authenticationService: IAuthenticationService,
```

**5. `platform/configuration/common/configurationService.ts`**

修改第26行的配置前缀：
```typescript
// 改为你的插件名称
export const CopilotConfigPrefix = 'yourExtension';
```

删除或简化第700-708行的匿名模式配置（因为现在只有匿名模式）：
```typescript
// 可以删除这些配置，因为不再需要区分匿名和GitHub模式
// 或者重命名为更简单的名称
export const CompletionsApiUrl = defineSetting<string>('completions.apiUrl', '', INTERNAL);
export const CompletionsApiKey = defineSetting<string>('completions.apiKey', '', INTERNAL);
export const CompletionsModelName = defineSetting<string>('completions.modelName', '', INTERNAL);
```

## 🔨 创建简化的鉴权服务

创建文件 `platform/authentication/simple/simpleAuthService.ts`：

```typescript
import { Event } from '../../../util/vs/base/common/event';
import { Disposable } from '../../../util/vs/base/common/lifecycle';
import { IConfigurationService } from '../../configuration/common/configurationService';

export interface IAuthenticationService {
    readonly _serviceBrand: undefined;
    getCopilotToken(): Promise<{ token: string }>;
    resetCopilotToken(): void;
    readonly onDidAuthenticationChange: Event<void>;
}

export class SimpleAuthenticationService extends Disposable implements IAuthenticationService {
    readonly _serviceBrand: undefined;

    // 空事件，因为我们不需要监听鉴权变化
    readonly onDidAuthenticationChange = Event.None;

    constructor(
        @IConfigurationService private configService: IConfigurationService
    ) {
        super();
    }

    async getCopilotToken(): Promise<{ token: string }> {
        const apiKey = this.configService.getConfig('yourExtension.completions.apiKey');
        if (!apiKey) {
            throw new Error('API密钥未配置，请在设置中配置 yourExtension.completions.apiKey');
        }
        return { token: apiKey };
    }

    resetCopilotToken(): void {
        // 不需要实现，因为我们不管理token生命周期
    }
}
```

## 📋 完整的删除清单

### 可以安全删除的配置项（在 configurationService.ts 中）：

```typescript
// ❌ 删除这些配置
ConfigKey.Internal.InlineEditsAllowAnonymous
ConfigKey.Internal.InlineEditsAnonymousApiUrl
ConfigKey.Internal.InlineEditsAnonymousApiKey
ConfigKey.Internal.InlineEditsAnonymousModelName
ConfigKey.Internal.CompletionsProviderAllowAnonymous
ConfigKey.Internal.CompletionsProviderAnonymousApiUrl
ConfigKey.Internal.CompletionsProviderAnonymousApiKey
ConfigKey.Internal.CompletionsProviderAnonymousModelName

// ✅ 替换为更简单的配置
ConfigKey.CompletionsApiUrl
ConfigKey.CompletionsApiKey
ConfigKey.CompletionsModelName
ConfigKey.InlineEditsApiUrl
ConfigKey.InlineEditsApiKey
ConfigKey.InlineEditsModelName
```

### 可以删除的导入：

在所有修改的文件中删除：
```typescript
// ❌ 删除
import { IAuthenticationService } from '../../../platform/authentication/common/authentication';
```

## 🎨 最终架构

```
你的插件
├── extension/
│   ├── completions/          # 普通补全
│   ├── inlineEdits/          # 智能编辑
│   └── xtab/                 # Xtab算法
├── platform/
│   ├── configuration/        # 配置服务（简化版）
│   ├── nesFetch/            # 请求服务（无鉴权检查）
│   ├── networking/          # 网络层
│   ├── endpoint/            # 端点管理
│   └── [其他平台服务]
└── util/                    # 工具类

❌ 不包含：platform/authentication/
```

## ✨ 优势总结

删除GitHub鉴权后的优势：

1. **代码量减少** - 减少约3000行鉴权相关代码
2. **启动更快** - 不需要等待token刷新
3. **更稳定** - 不会因为GitHub服务问题导致功能不可用
4. **更灵活** - 可以轻松切换不同的API提供商
5. **更安全** - API密钥由用户自己管理，不经过第三方

## 🚦 迁移后的工作流程

```
用户配置API → 插件读取配置 → 直接调用API → 返回补全结果
```

简单、直接、高效！