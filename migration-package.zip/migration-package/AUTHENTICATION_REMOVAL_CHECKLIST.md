# GitHub鉴权代码删除检查清单

## ✅ 删除鉴权的理由

你已经实现了 `allowAnonymous` 机制，可以完全绕过GitHub登录。删除GitHub鉴权代码后：

- ✅ **代码更简洁** - 减少约3000行代码
- ✅ **无外部依赖** - 不依赖GitHub OAuth服务
- ✅ **启动更快** - 无需等待token刷新
- ✅ **更适合企业** - 内部部署无需GitHub账号
- ✅ **易于维护** - 不需要处理token过期、配额等问题

## 📝 详细删除步骤

### 第一步：删除整个鉴权文件夹

```bash
# 在你的新项目中，不要复制这个文件夹
❌ platform/authentication/
```

### 第二步：修改核心文件

#### 1. `extension/completions/vscode-node/completionsProvider.ts`

**删除导入：**
```typescript
// ❌ 删除第7行
import { IAuthenticationService } from '../../../platform/authentication/common/authentication';
```

**删除构造函数参数：**
```typescript
// ❌ 删除第36行
@IAuthenticationService private authService: IAuthenticationService,
```

**简化第88-108行：**
```typescript
// ❌ 删除
const allowAnonymous = this.configService.getConfig(ConfigKey.Internal.CompletionsProviderAllowAnonymous);

if (allowAnonymous) {
    const anonymousUrl = this.configService.getConfig(ConfigKey.Internal.CompletionsProviderAnonymousApiUrl);
    const anonymousApiKey = this.configService.getConfig(ConfigKey.Internal.CompletionsProviderAnonymousApiKey);
    const anonymousModelName = this.configService.getConfig(ConfigKey.Internal.CompletionsProviderAnonymousModelName);
    if (anonymousUrl && anonymousApiKey) {
        url = anonymousUrl;
        secretKey = anonymousApiKey;
        modelName = anonymousModelName;
    }
}

if (!url) {
    this.tracer.throws('No completions URL configured');
    throw new Error('No completions URL configured');
}

if (!secretKey) {
    secretKey = (await this.authService.getCopilotToken()).token;
}

// ✅ 替换为
const url = this.configService.getConfig('yourExtension.completions.apiUrl');
const secretKey = this.configService.getConfig('yourExtension.completions.apiKey');
const modelName = this.configService.getConfig('yourExtension.completions.modelName');

if (!url || !secretKey) {
    this.tracer.throws('API配置未设置');
    throw new Error('请在设置中配置API地址和密钥');
}
```

#### 2. `extension/xtab/node/xtabProvider.ts`

**完全重写第1278-1309行的 `getEndpoint` 方法：**
```typescript
private getEndpoint(configuredModelName: string | undefined): { endpoint: ChatEndpoint; secretKey?: string } {
    const url = this.configService.getConfig('yourExtension.inlineEdits.apiUrl');
    const apiKey = this.configService.getConfig('yourExtension.inlineEdits.apiKey');

    if (!url || !apiKey) {
        throw new Error('请在设置中配置智能编辑API地址和密钥');
    }

    return {
        endpoint: this.instaService.createInstance(XtabEndpoint, url, apiKey, configuredModelName),
        secretKey: apiKey
    };
}
```

#### 3. `extension/inlineEdits/vscode-node/inlineEditProviderFeature.ts`

**删除导入：**
```typescript
// ❌ 删除第8行
import { IAuthenticationService } from '../../../platform/authentication/common/authentication';
```

**删除第52-53行：**
```typescript
// ❌ 删除
private readonly _copilotToken = observableFromEvent(this, this._authenticationService.onDidAuthenticationChange, () => this._authenticationService.copilotToken);
private readonly _allowAnonymous = this._configurationService.getConfigObservable(ConfigKey.Internal.InlineEditsAllowAnonymous);
```

**简化第55-76行：**
```typescript
// ❌ 删除整个复杂的逻辑
public readonly inlineEditsEnabled = derived(this, (reader) => {
    const allowAnonymous = this._allowAnonymous.read(reader);
    const copilotToken = this._copilotToken.read(reader);
    // ... 复杂的token检查
});

// ✅ 替换为
public readonly inlineEditsEnabled = derived(this, (reader) => {
    const apiUrl = this._configurationService.getConfig('yourExtension.inlineEdits.apiUrl');
    const apiKey = this._configurationService.getConfig('yourExtension.inlineEdits.apiKey');
    return !!(apiUrl && apiKey);
});
```

**删除构造函数参数：**
```typescript
// ❌ 删除第92行
@IAuthenticationService private readonly _authenticationService: IAuthenticationService,
```

**删除第78-79行：**
```typescript
// ❌ 删除
private readonly _internalActionsEnabled = derived(this, (reader) => {
    return !!this._copilotToken.read(reader)?.isInternal && !this._hideInternalInterface.read(reader);
});

// ✅ 如果需要内部功能，改为基于配置
private readonly _internalActionsEnabled = this._configurationService.getConfigObservable('yourExtension.enableInternalFeatures');
```

#### 4. `platform/nesFetch/node/completionsFetchServiceImpl.ts`

**删除导入：**
```typescript
// ❌ 删除第12行
import { IAuthenticationService } from '../../authentication/common/authentication';
```

**删除构造函数参数：**
```typescript
// ❌ 删除第31行
@IAuthenticationService private authService: IAuthenticationService,
```

**删除第124-136行的配额检查：**
```typescript
// ❌ 完全删除
// 只有在有 copilotToken 的情况下才处理配额相关逻辑
if (this.authService.copilotToken) {
    if (response.status === 200 && this.authService.copilotToken.isFreeUser && this.authService.copilotToken.isChatQuotaExceeded) {
        this.authService.resetCopilotToken();
    }

    if (response.status !== 200 && response.status === 402) {
        // When we receive a 402, we have exceed the free tier quota
        // This is stored on the token so let's refresh it
        this.authService.resetCopilotToken(response.status);
        return Result.error<CompletionsFetchFailure>({ kind: 'quota-exceeded' });
    }
}
```

#### 5. `platform/configuration/common/configurationService.ts`

**修改第26行：**
```typescript
// ❌ 删除
export const CopilotConfigPrefix = 'github.copilot';

// ✅ 改为
export const CopilotConfigPrefix = 'yourExtension';
```

**删除第700-708行的匿名配置：**
```typescript
// ❌ 删除（因为现在只有一种模式）
export const InlineEditsAllowAnonymous = defineSetting<boolean>('chat.advanced.inlineEdits.allowAnonymous', false, INTERNAL);
export const InlineEditsAnonymousApiUrl = defineValidatedSetting<string | undefined>('chat.advanced.inlineEdits.anonymousApiUrl', vString(), undefined, INTERNAL);
export const InlineEditsAnonymousApiKey = defineValidatedSetting<string | undefined>('chat.advanced.inlineEdits.anonymousApiKey', vString(), undefined, INTERNAL);
export const InlineEditsAnonymousModelName = defineValidatedSetting<string | undefined>('chat.advanced.inlineEdits.anonymousModelName', vString(), undefined, INTERNAL);

export const CompletionsProviderAllowAnonymous = defineSetting<boolean>('chat.advanced.completionsProvider.allowAnonymous', false, INTERNAL);
export const CompletionsProviderAnonymousApiUrl = defineValidatedSetting<string | undefined>('chat.advanced.completionsProvider.anonymousApiUrl', vString(), undefined, INTERNAL);
export const CompletionsProviderAnonymousApiKey = defineValidatedSetting<string | undefined>('chat.advanced.completionsProvider.anonymousApiKey', vString(), undefined, INTERNAL);
export const CompletionsProviderAnonymousModelName = defineValidatedSetting<string | undefined>('chat.advanced.completionsProvider.anonymousModelName', vString(), undefined, INTERNAL);

// ✅ 添加简化的配置
export const CompletionsApiUrl = defineSetting<string>('completions.apiUrl', '');
export const CompletionsApiKey = defineSetting<string>('completions.apiKey', '');
export const CompletionsModelName = defineSetting<string>('completions.modelName', '');
export const InlineEditsApiUrl = defineSetting<string>('inlineEdits.apiUrl', '');
export const InlineEditsApiKey = defineSetting<string>('inlineEdits.apiKey', '');
export const InlineEditsModelName = defineSetting<string>('inlineEdits.modelName', '');
```

### 第三步：创建简化的服务注册

在你的新插件的激活函数中：

```typescript
import { SimpleAuthenticationService } from './platform/authentication/simple/simpleAuthService';

function registerServices(builder: IInstantiationServiceBuilder, context: ExtensionContext) {
    // 注册简化的鉴权服务
    builder.registerService(IAuthenticationService, SimpleAuthenticationService);

    // 注册其他必需服务
    builder.registerService(IConfigurationService, ConfigurationServiceImpl);
    builder.registerService(IFetcherService, FetcherServiceImpl);
    builder.registerService(ICompletionsFetchService, CompletionsFetchService);
    // ... 其他服务
}
```

## 🧪 测试删除后的功能

### 测试清单：

- [ ] 基础代码补全正常工作
- [ ] 智能多行编辑正常工作
- [ ] 配置修改后立即生效
- [ ] 错误提示清晰（API未配置时）
- [ ] 网络错误处理正确
- [ ] 不同语言的补全都正常

### 测试配置：

```json
{
  "yourExtension.completions.apiUrl": "https://api.openai.com/v1/completions",
  "yourExtension.completions.apiKey": "sk-xxx",
  "yourExtension.completions.modelName": "gpt-3.5-turbo-instruct",
  "yourExtension.inlineEdits.apiUrl": "https://api.openai.com/v1/chat/completions",
  "yourExtension.inlineEdits.apiKey": "sk-xxx",
  "yourExtension.inlineEdits.modelName": "gpt-4",
  "yourExtension.inlineEdits.enabled": true
}
```

## 📊 代码统计

### 删除前：
- 鉴权相关代码：~3000行
- 总代码量：~50000行

### 删除后：
- 鉴权相关代码：~50行（简化版）
- 总代码量：~47000行
- **减少：6%的代码量**

## 🎉 总结

**强烈建议完全删除GitHub鉴权代码**，原因：

1. ✅ 你的 `allowAnonymous` 实现已经证明了不需要GitHub鉴权
2. ✅ 简化后的代码更易理解和维护
3. ✅ 减少了外部依赖和潜在的故障点
4. ✅ 更符合你的使用场景（自托管API）

删除后，整个鉴权流程变为：
```
读取配置 → 验证配置 → 使用API密钥 → 完成
```

简单、直接、高效！