# 代码补全模块迁移包

本文件夹包含了从 GitHub Copilot Chat 插件中提取的代码补全模块，可以直接迁移到你的新插件项目中。

## 📦 已包含的模块

### 核心补全功能
- **extension/completions/** - 普通代码补全提供者
- **extension/inlineEdits/** - 内联编辑和智能补全
- **extension/xtab/** - Xtab智能补全提供者（核心算法）

### 平台服务层
- **platform/nesFetch/** - 补全请求服务
- **platform/configuration/** - 配置服务
- **platform/networking/** - 网络请求服务
- **platform/endpoint/** - API端点管理
- **platform/chat/** - 聊天和流式响应处理
- **platform/inlineEdits/** - 内联编辑数据类型和逻辑
- **platform/diff/** - 差异计算服务
- **platform/editing/** - 编辑操作
- **platform/editSurvivalTracking/** - 编辑存活率跟踪
- **platform/tokenizer/** - Token计数器
- **platform/log/** - 日志服务
- **platform/telemetry/** - 遥测服务
- **platform/workspace/** - 工作区服务
- **platform/git/** - Git集成
- **platform/ignore/** - 忽略文件处理
- **platform/languageContextProvider/** - 语言上下文提供者
- **platform/languages/** - 语言特性服务
- **platform/languageServer/** - 语言服务器
- **platform/notebook/** - Notebook支持
- **platform/env/** - 环境服务
- **platform/extContext/** - 扩展上下文
- **platform/heatmap/** - 热力图服务
- **platform/simulationTestContext/** - 测试上下文
- **platform/inlineCompletions/** - 内联补全API

### 工具类
- **util/** - 所有工具函数和VS Code基础类型
- **vscodeTypes.ts** - VS Code类型定义
- **extension/inlineChat/vscode-node/inlineChatHint.ts** - 内联聊天提示

## 🔧 集成步骤

### 1. 复制文件到新项目
将整个 `migration-package` 文件夹的内容复制到你的新插件项目的 `src` 目录下。

### 2. 安装依赖
在你的新项目的 `package.json` 中添加以下依赖：

```json
{
  "dependencies": {
    "@vscode/prompt-tsx": "^0.4.0-alpha.5",
    "@vscode/copilot-api": "^0.1.13",
    "@vscode/l10n": "^0.0.18",
    "undici": "^7.11.0"
  },
  "devDependencies": {
    "@types/node": "^22.16.3",
    "@types/vscode": "^1.102.0"
  }
}
```

### 3. 配置 package.json

在你的插件的 `package.json` 中添加以下配置项：

```json
{
  "contributes": {
    "configuration": [
      {
        "title": "代码补全配置",
        "properties": {
          "yourExtension.completions.allowAnonymous": {
            "type": "boolean",
            "default": true,
            "description": "允许使用匿名模式（不需要GitHub登录）"
          },
          "yourExtension.completions.apiUrl": {
            "type": "string",
            "default": "",
            "description": "补全API的URL地址"
          },
          "yourExtension.completions.apiKey": {
            "type": "string",
            "default": "",
            "description": "补全API的密钥"
          },
          "yourExtension.completions.modelName": {
            "type": "string",
            "default": "",
            "description": "使用的模型名称"
          },
          "yourExtension.inlineEdits.enabled": {
            "type": "boolean",
            "default": true,
            "description": "启用智能内联编辑建议"
          },
          "yourExtension.enable": {
            "type": "object",
            "default": {
              "*": true,
              "plaintext": false,
              "markdown": false
            },
            "description": "为不同语言启用/禁用补全"
          }
        }
      }
    ]
  }
}
```

### 4. 修改配置键名

你需要将所有配置键从 `github.copilot.chat.advanced.*` 改为你自己的前缀，例如 `yourExtension.*`。

主要修改文件：
- `platform/configuration/common/configurationService.ts` - 修改 `CopilotConfigPrefix` 常量

### 5. 简化鉴权服务

创建一个简化的鉴权服务实现 `platform/authentication/simple/simpleAuthService.ts`：

```typescript
import { IAuthenticationService } from '../common/authentication';
import { IConfigurationService } from '../../configuration/common/configurationService';

export class SimpleAuthenticationService implements IAuthenticationService {
    readonly _serviceBrand: undefined;

    constructor(
        @IConfigurationService private configService: IConfigurationService
    ) {}

    async getCopilotToken() {
        const apiKey = this.configService.getConfig('yourExtension.completions.apiKey');
        if (!apiKey) {
            throw new Error('API密钥未配置');
        }
        return { token: apiKey };
    }

    // 实现其他必需的接口方法...
}
```

### 6. 注册服务

在你的插件激活函数中注册所有服务（参考 `src/extension/extension/vscode/extension.ts`）：

```typescript
export async function activate(context: vscode.ExtensionContext) {
    const instantiationService = createInstantiationService(context);

    // 注册补全提供者
    const provider = instantiationService.createInstance(InlineCompletionProviderImpl, ...);

    context.subscriptions.push(
        vscode.languages.registerInlineCompletionItemProvider('*', provider)
    );
}
```

## ⚠️ 关于鉴权代码的建议

### 推荐方案：完全移除GitHub鉴权，使用简化版本

**原因：**
1. ✅ 你已经实现了 `allowAnonymous` 机制，可以完全绕过GitHub登录
2. ✅ 代码会更简洁，没有复杂的OAuth流程
3. ✅ 减少依赖，降低维护成本
4. ✅ 更适合企业内部或自托管场景

**需要删除的鉴权相关代码：**
- 所有 `platform/authentication/` 下的GitHub OAuth实现
- `copilotToken`、`copilotTokenManager`、`copilotTokenStore` 相关代码
- `platform/nesFetch/node/completionsFetchServiceImpl.ts` 中第124-136行的配额检查逻辑

**需要保留的：**
- `IAuthenticationService` 接口定义（简化版）
- 配置服务中的匿名模式配置项

### 简化后的鉴权流程

```typescript
// 在 completionsProvider.ts 中
const apiUrl = this.configService.getConfig('yourExtension.completions.apiUrl');
const apiKey = this.configService.getConfig('yourExtension.completions.apiKey');
const modelName = this.configService.getConfig('yourExtension.completions.modelName');

if (!apiUrl || !apiKey) {
    throw new Error('请先配置API地址和密钥');
}

// 直接使用配置的密钥，无需复杂的token管理
const response = await this.fetchService.fetch(apiUrl, apiKey, params, ...);
```

## 📝 关键修改点

### 1. completionsProvider.ts (第88-108行)
```typescript
// 删除原有的GitHub token获取逻辑
// 改为直接使用配置的API密钥
const apiKey = this.configService.getConfig('yourExtension.completions.apiKey');
```

### 2. xtabProvider.ts (第1278-1309行)
```typescript
// 简化 getEndpoint 方法
private getEndpoint(configuredModelName: string | undefined) {
    const url = this.configService.getConfig('yourExtension.inlineEdits.apiUrl');
    const apiKey = this.configService.getConfig('yourExtension.inlineEdits.apiKey');

    return {
        endpoint: this.instaService.createInstance(XtabEndpoint, url, apiKey, configuredModelName),
        secretKey: apiKey
    };
}
```

### 3. completionsFetchServiceImpl.ts (第124-136行)
```typescript
// 删除配额检查逻辑
// 因为你使用自己的API，不需要检查GitHub的配额
```

### 4. inlineEditProviderFeature.ts (第55-76行)
```typescript
// 简化启用逻辑
public readonly inlineEditsEnabled = derived(this, (reader) => {
    const apiUrl = this._configurationService.getConfig('yourExtension.completions.apiUrl');
    const apiKey = this._configurationService.getConfig('yourExtension.completions.apiKey');
    return !!(apiUrl && apiKey);
});
```

## 🎯 配置示例

用户在 VS Code 的 settings.json 中配置：

```json
{
  "yourExtension.completions.allowAnonymous": true,
  "yourExtension.completions.apiUrl": "https://your-api.com/v1/completions",
  "yourExtension.completions.apiKey": "your-api-key-here",
  "yourExtension.completions.modelName": "your-model-name",
  "yourExtension.inlineEdits.enabled": true,
  "yourExtension.inlineEdits.apiUrl": "https://your-api.com/v1/chat/completions",
  "yourExtension.inlineEdits.apiKey": "your-api-key-here",
  "yourExtension.inlineEdits.modelName": "your-xtab-model",
  "yourExtension.enable": {
    "*": true,
    "plaintext": false,
    "markdown": false
  }
}
```

## 🚀 测试建议

1. **基础补全测试** - 在简单的代码文件中测试基本的代码补全
2. **智能编辑测试** - 测试多行编辑和上下文感知补全
3. **性能测试** - 确保debounce和缓存机制正常工作
4. **错误处理** - 测试API失败、网络错误等异常情况

## 📚 核心概念

### 两种补全模式

1. **普通补全 (Completions)** - 单行代码补全
   - 提供者：`CompletionsProvider`
   - 触发：光标停留时自动触发
   - 特点：快速、简单

2. **智能编辑 (Inline Edits/NES)** - 多行智能编辑
   - 提供者：`XtabProvider`
   - 触发：编辑后光标移动时
   - 特点：上下文感知、多行编辑

### 依赖注入系统

项目使用了自定义的DI系统（`IInstantiationService`），所有服务都通过构造函数注入。确保在新项目中正确注册所有服务。

## ⚡ 性能优化

- **Debounce机制** - 避免频繁请求
- **缓存系统** - 复用相似请求的结果
- **流式响应** - 逐步显示补全结果
- **Token限制** - 控制提示词大小

## 🔍 调试技巧

1. 启用日志记录：
```json
{
  "yourExtension.inlineEdits.logContextRecorder.enabled": true
}
```

2. 查看输出面板中的日志
3. 使用 VS Code 的开发者工具查看网络请求

## 📞 常见问题

**Q: 为什么补全不工作？**
A: 检查API配置是否正确，查看输出面板的错误日志。

**Q: 如何调整补全的触发时机？**
A: 修改 `ConfigKey.Internal.InlineEditsDebounce` 配置项。

**Q: 如何禁用某些语言的补全？**
A: 在 `yourExtension.enable` 配置中设置对应语言为 `false`。

## 📄 许可证

请确保遵守原项目的 MIT 许可证。