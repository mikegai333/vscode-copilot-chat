# 快速开始指南

## 🚀 5分钟快速集成

### 步骤1: 复制文件 (1分钟)

```bash
# 将 migration-package 文件夹复制到你的新插件项目
cp -r migration-package/* your-plugin/src/
```

### 步骤2: 安装依赖 (1分钟)

在你的 `package.json` 中添加：

```json
{
  "dependencies": {
    "@vscode/prompt-tsx": "^0.4.0-alpha.5",
    "@vscode/copilot-api": "^0.1.13",
    "@vscode/l10n": "^0.0.18",
    "undici": "^7.11.0"
  }
}
```

然后运行：
```bash
npm install
```

### 步骤3: 修改配置前缀 (1分钟)

在 `platform/configuration/common/configurationService.ts` 第26行：

```typescript
// 改为你的插件名称
export const CopilotConfigPrefix = 'yourExtension';
```

### 步骤4: 简化鉴权 (2分钟)

#### 4.1 创建简化的鉴权服务

创建文件 `platform/authentication/simple/simpleAuthService.ts`：

```typescript
import { Event } from '../../../util/vs/base/common/event';
import { Disposable } from '../../../util/vs/base/common/lifecycle';
import { IConfigurationService } from '../../configuration/common/configurationService';
import { createServiceIdentifier } from '../../../util/common/services';

export const IAuthenticationService = createServiceIdentifier<IAuthenticationService>('IAuthenticationService');

export interface IAuthenticationService {
    readonly _serviceBrand: undefined;
    getCopilotToken(): Promise<{ token: string }>;
    resetCopilotToken(): void;
    readonly onDidAuthenticationChange: Event<void>;
    readonly copilotToken: { token: string } | undefined;
}

export class SimpleAuthenticationService extends Disposable implements IAuthenticationService {
    readonly _serviceBrand: undefined;
    readonly onDidAuthenticationChange = Event.None;

    constructor(
        @IConfigurationService private configService: IConfigurationService
    ) {
        super();
    }

    get copilotToken() {
        const apiKey = this.configService.getConfig('yourExtension.completions.apiKey');
        return apiKey ? { token: apiKey } : undefined;
    }

    async getCopilotToken(): Promise<{ token: string }> {
        const apiKey = this.configService.getConfig('yourExtension.completions.apiKey');
        if (!apiKey) {
            throw new Error('API密钥未配置');
        }
        return { token: apiKey };
    }

    resetCopilotToken(): void {
        // 不需要实现
    }
}
```

#### 4.2 修改导入

在以下文件中，将鉴权服务导入改为：

```typescript
// 在这些文件中修改导入
// - extension/completions/vscode-node/completionsProvider.ts
// - extension/inlineEdits/vscode-node/inlineEditProviderFeature.ts
// - platform/nesFetch/node/completionsFetchServiceImpl.ts

// ❌ 删除
import { IAuthenticationService } from '../../../platform/authentication/common/authentication';

// ✅ 改为
import { IAuthenticationService } from '../../../platform/authentication/simple/simpleAuthService';
```

### 步骤5: 注册服务 (在你的插件激活函数中)

```typescript
import * as vscode from 'vscode';
import { InstantiationServiceBuilder } from './util/common/services';
import { SimpleAuthenticationService, IAuthenticationService } from './platform/authentication/simple/simpleAuthService';
import { ConfigurationServiceImpl } from './platform/configuration/vscode/configurationServiceImpl';
import { IConfigurationService } from './platform/configuration/common/configurationService';
import { InlineEditProviderFeature } from './extension/inlineEdits/vscode-node/inlineEditProviderFeature';

export async function activate(context: vscode.ExtensionContext) {
    // 创建依赖注入容器
    const serviceBuilder = new InstantiationServiceBuilder();

    // 注册核心服务
    serviceBuilder.registerService(IConfigurationService, ConfigurationServiceImpl);
    serviceBuilder.registerService(IAuthenticationService, SimpleAuthenticationService);
    // ... 注册其他服务

    const instantiationService = serviceBuilder.seal();

    // 创建补全功能
    const inlineEditFeature = instantiationService.createInstance(InlineEditProviderFeature);
    context.subscriptions.push(inlineEditFeature);

    return {
        // 导出API（如果需要）
    };
}
```

## ⚙️ 配置你的插件

在 `package.json` 中添加配置项：

```json
{
  "contributes": {
    "configuration": {
      "title": "你的插件名称",
      "properties": {
        "yourExtension.completions.apiUrl": {
          "type": "string",
          "default": "",
          "description": "代码补全API地址"
        },
        "yourExtension.completions.apiKey": {
          "type": "string",
          "default": "",
          "description": "API密钥"
        },
        "yourExtension.completions.modelName": {
          "type": "string",
          "default": "gpt-3.5-turbo-instruct",
          "description": "补全模型名称"
        },
        "yourExtension.inlineEdits.enabled": {
          "type": "boolean",
          "default": true,
          "description": "启用智能内联编辑"
        },
        "yourExtension.inlineEdits.apiUrl": {
          "type": "string",
          "default": "",
          "description": "智能编辑API地址"
        },
        "yourExtension.inlineEdits.apiKey": {
          "type": "string",
          "default": "",
          "description": "智能编辑API密钥"
        },
        "yourExtension.inlineEdits.modelName": {
          "type": "string",
          "default": "gpt-4",
          "description": "智能编辑模型名称"
        },
        "yourExtension.enable": {
          "type": "object",
          "default": {
            "*": true,
            "plaintext": false,
            "markdown": false
          },
          "description": "为不同语言启用/禁用补全"
        }
      }
    }
  }
}
```

## 🧪 测试配置

在 VS Code 的 `settings.json` 中：

```json
{
  "yourExtension.completions.apiUrl": "https://api.openai.com/v1/completions",
  "yourExtension.completions.apiKey": "sk-your-api-key",
  "yourExtension.completions.modelName": "gpt-3.5-turbo-instruct",
  "yourExtension.inlineEdits.enabled": true,
  "yourExtension.inlineEdits.apiUrl": "https://api.openai.com/v1/chat/completions",
  "yourExtension.inlineEdits.apiKey": "sk-your-api-key",
  "yourExtension.inlineEdits.modelName": "gpt-4",
  "yourExtension.enable": {
    "*": true,
    "plaintext": false,
    "markdown": false
  }
}
```

## ✅ 验证安装

1. 打开一个代码文件
2. 开始输入代码
3. 应该看到补全建议出现
4. 按 Tab 接受补全

## 🐛 常见问题

### 问题1: 补全不出现

**检查：**
- API配置是否正确
- 查看输出面板的错误日志
- 确认语言在 `enable` 配置中启用

### 问题2: 编译错误

**解决：**
- 确保所有依赖都已安装
- 检查 TypeScript 版本 (需要 5.0+)
- 运行 `npm install` 重新安装依赖

### 问题3: 服务注册失败

**解决：**
- 确保所有服务都按正确顺序注册
- 检查依赖注入的参数装饰器
- 参考原项目的服务注册代码

## 📚 下一步

- 阅读 `MIGRATION_GUIDE.md` 了解详细的修改步骤
- 阅读 `AUTHENTICATION_REMOVAL_CHECKLIST.md` 了解如何删除鉴权代码
- 阅读 `FILE_LIST.md` 了解所有文件的作用

## 🎯 关键提示

1. **不要忘记修改配置前缀** - 从 `github.copilot` 改为 `yourExtension`
2. **删除所有GitHub鉴权代码** - 使用简化的鉴权服务
3. **保留依赖注入系统** - 这是整个架构的基础
4. **测试每个步骤** - 确保每个修改都能正常工作

祝你迁移顺利！🎉