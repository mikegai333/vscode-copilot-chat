/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import * as vscode from 'vscode';
import { commands, languages, window } from 'vscode';

import { ConfigKey, IConfigurationService } from '../../../platform/configuration/common/configurationService';
import { IEnvService } from '../../../platform/env/common/envService';
import { IVSCodeExtensionContext } from '../../../platform/extContext/common/extensionContext';
import { InlineEditRequestLogContext } from '../../../platform/inlineEdits/common/inlineEditLogContext';
import { ObservableGit } from '../../../platform/inlineEdits/common/observableGit';
import { NesHistoryContextProvider } from '../../../platform/inlineEdits/common/workspaceEditTracker/nesHistoryContextProvider';
import { ILogService } from '../../../platform/log/common/logService';
import { IExperimentationService } from '../../../platform/telemetry/common/nullExperimentationService';
import { isNotebookCell } from '../../../util/common/notebooks';
import { createTracer } from '../../../util/common/tracing';
import { Disposable } from '../../../util/vs/base/common/lifecycle';
import { autorun, derived, derivedDisposable } from '../../../util/vs/base/common/observable';
import { join } from '../../../util/vs/base/common/path';
import { URI } from '../../../util/vs/base/common/uri';
import { Position } from '../../../util/vs/editor/common/core/position';
import { IInstantiationService } from '../../../util/vs/platform/instantiation/common/instantiation';
import { IExtensionContribution } from '../../common/contributions';
import { CompletionsProvider } from '../../completions/vscode-node/completionsProvider';
import { unificationStateObservable } from '../../completions/vscode-node/completionsUnificationContribution';
import { jumpToPositionCommandId } from '../common/jumpToCursorPosition';
import { TelemetrySender } from '../node/nextEditProviderTelemetry';
import { InlineEditDebugComponent, reportFeedbackCommandId } from './components/inlineEditDebugComponent';
import { LogContextRecorder } from './components/logContextRecorder';
import { DiagnosticsNextEditProvider } from './features/diagnosticsInlineEditProvider';
import { InlineCompletionProviderImpl } from './inlineCompletionProvider';
import { InlineEditModel } from './inlineEditModel';
import { InlineEditLogger } from './parts/inlineEditLogger';
import { LastEditTimeTracker } from './parts/lastEditTimeTracker';
import { VSCodeWorkspace } from './parts/vscodeWorkspace';
import { makeSettable } from './utils/observablesUtils';

const TRIGGER_INLINE_EDIT_ON_ACTIVE_EDITOR_CHANGE = false; // otherwise, eg, NES would trigger just when going through search results
const useEnhancedNotebookNESContextKey = 'github.copilot.chat.enableEnhancedNotebookNES';

export class InlineEditProviderFeature extends Disposable implements IExtensionContribution {

	private readonly _inlineEditsProviderId = makeSettable(this._configurationService.getExperimentBasedConfigObservable(ConfigKey.Internal.InlineEditsProviderId, this._expService));

	private readonly _hideInternalInterface = this._configurationService.getConfigObservable(ConfigKey.Internal.InlineEditsHideInternalInterface);
	private readonly _enableDiagnosticsProvider = this._configurationService.getExperimentBasedConfigObservable(ConfigKey.InlineEditsEnableDiagnosticsProvider, this._expService);
	private readonly _enableCompletionsProvider = this._configurationService.getExperimentBasedConfigObservable(ConfigKey.Internal.InlineEditsEnableCompletionsProvider, this._expService);
	private readonly _yieldToCopilot = this._configurationService.getExperimentBasedConfigObservable(ConfigKey.Internal.InlineEditsYieldToCopilot, this._expService);
	private readonly _excludedProviders = this._configurationService.getExperimentBasedConfigObservable(ConfigKey.Internal.InlineEditsExcludedProviders, this._expService).map(v => v ? v.split(',').map(v => v.trim()).filter(v => v !== '') : []);

	public readonly inlineEditsEnabled = derived(this, (reader) => {
		// 直接检查API配置是否完整
		const apiUrl = this._configurationService.getConfig(ConfigKey.Internal.InlineEditsAnonymousApiUrl);
		const apiKey = this._configurationService.getConfig(ConfigKey.Internal.InlineEditsAnonymousApiKey);
		return !!(apiUrl && apiKey);
	});

	private readonly _internalActionsEnabled = derived(this, (reader) => {
		// 简化：基于配置而不是token
		return !this._hideInternalInterface.read(reader);
	});

	public readonly isInlineEditsLogFileEnabledObservable = this._configurationService.getConfigObservable(ConfigKey.Internal.InlineEditsLogContextRecorderEnabled);

	private readonly _workspace = derivedDisposable(this, _reader => {
		return this._instantiationService.createInstance(VSCodeWorkspace);
	});

	constructor(
		@IVSCodeExtensionContext private readonly _vscodeExtensionContext: IVSCodeExtensionContext,
		@IConfigurationService private readonly _configurationService: IConfigurationService,
		@IExperimentationService private readonly _expService: IExperimentationService,
		@IEnvService private readonly _envService: IEnvService,
		@ILogService private readonly _logService: ILogService,
		@IInstantiationService private readonly _instantiationService: IInstantiationService,
		@IExperimentationService _experimentationService: IExperimentationService,
	) {
		super();

		const tracer = createTracer(['NES', 'Feature'], (s) => this._logService.trace(s));
		const constructorTracer = tracer.sub('constructor');
		const hasUpdatedNesSettingKey = 'copilot.chat.nextEdits.hasEnabledNesInSettings';
		const enableEnhancedNotebookNES = this._configurationService.getExperimentBasedConfig(ConfigKey.Internal.UseAlternativeNESNotebookFormat, _experimentationService) || this._configurationService.getExperimentBasedConfig(ConfigKey.UseAlternativeNESNotebookFormat, _experimentationService);
		const unificationState = unificationStateObservable(this);

		commands.executeCommand('setContext', useEnhancedNotebookNESContextKey, enableEnhancedNotebookNES);

		// 删除基于GitHub token的自动启用逻辑，改为用户手动配置

		this._register(autorun(reader => {
			if (!this.inlineEditsEnabled.read(reader)) { return; }

			const logger = reader.store.add(this._instantiationService.createInstance(InlineEditLogger));

			const statelessProviderId = this._inlineEditsProviderId.read(reader);

			const workspace = this._workspace.read(reader);
			const git = reader.store.add(this._instantiationService.createInstance(ObservableGit));
			const historyContextProvider = new NesHistoryContextProvider(workspace, git);

			let diagnosticsProvider: DiagnosticsNextEditProvider | undefined = undefined;
			if (this._enableDiagnosticsProvider.read(reader)) {
				diagnosticsProvider = reader.store.add(this._instantiationService.createInstance(DiagnosticsNextEditProvider, workspace, git));
			}

			const completionsProvider = (this._enableCompletionsProvider.read(reader)
				? reader.store.add(this._instantiationService.createInstance(CompletionsProvider, workspace))
				: undefined);

			const model = reader.store.add(this._instantiationService.createInstance(InlineEditModel, statelessProviderId, workspace, historyContextProvider, diagnosticsProvider, completionsProvider));

			const recordingDirPath = join(this._vscodeExtensionContext.globalStorageUri.fsPath, 'logContextRecordings');

			const isInlineEditLogFileEnabled = this.isInlineEditsLogFileEnabledObservable.read(reader);

			let logContextRecorder: LogContextRecorder | undefined;
			if (isInlineEditLogFileEnabled) {
				logContextRecorder = reader.store.add(this._instantiationService.createInstance(LogContextRecorder, recordingDirPath, logger));
			} else {
				void LogContextRecorder.cleanupOldRecordings(recordingDirPath);
			}

			const inlineEditDebugComponent = reader.store.add(new InlineEditDebugComponent(this._internalActionsEnabled, this.inlineEditsEnabled, model.debugRecorder, this._inlineEditsProviderId));

			const telemetrySender = this._register(this._instantiationService.createInstance(TelemetrySender));

			const provider = this._instantiationService.createInstance(InlineCompletionProviderImpl, model, logger, logContextRecorder, inlineEditDebugComponent, telemetrySender);

			const unificationStateValue = unificationState.read(reader);
			let excludes = this._excludedProviders.read(reader);
			if (unificationStateValue?.modelUnification) {
				excludes = excludes.slice(0);
				if (!excludes.includes('completions')) {
					excludes.push('completions');
				}
				if (!excludes.includes('github.copilot')) {
					excludes.push('github.copilot');
				}
			}

			reader.store.add(languages.registerInlineCompletionItemProvider('*', provider, {
				displayName: provider.displayName,
				yieldTo: this._yieldToCopilot.read(reader) ? ['github.copilot'] : undefined,
				debounceDelayMs: 0, // set 0 debounce to ensure consistent delays/timings
				groupId: 'nes',
				excludes,
			}));

			if (TRIGGER_INLINE_EDIT_ON_ACTIVE_EDITOR_CHANGE) {
				const lastEditTimeTracker = new LastEditTimeTracker(model.workspace);
				reader.store.add(window.onDidChangeActiveTextEditor((activeEditor) => {
					if (activeEditor !== undefined && lastEditTimeTracker.hadEditsRecently) {
						model.onChange.trigger(undefined);
					}
				}));
				reader.store.add(lastEditTimeTracker);
			}

			reader.store.add(commands.registerCommand(learnMoreCommandId, () => {
				this._envService.openExternal(URI.parse(learnMoreLink));
			}));

			reader.store.add(commands.registerCommand(jumpToPositionCommandId, (position: Position) => {
				const currentEditor = window.activeTextEditor;
				if (!currentEditor) {
					return;
				}
				// vscode API uses 0-based line and column numbers
				const range = new vscode.Range(position.lineNumber - 1, position.column - 1, position.lineNumber - 1, position.column - 1);
				currentEditor.selection = new vscode.Selection(range.start, range.end);
				currentEditor.revealRange(range, vscode.TextEditorRevealType.InCenterIfOutsideViewport);

				model.onChange.trigger(undefined);
			}));

			reader.store.add(commands.registerCommand(clearCacheCommandId, () => {
				model.nextEditProvider.clearCache();
			}));

			reader.store.add(commands.registerCommand(reportNotebookNESIssueCommandId, () => {
				const activeNotebook = window.activeNotebookEditor;
				const document = window.activeTextEditor?.document;
				if (!activeNotebook || !document || !isNotebookCell(document.uri)) {
					return;
				}
				const doc = model.workspace.getDocumentByTextDocument(document);
				const selection = activeNotebook.selection;
				if (!selection || !doc) {
					return;
				}

				const logContext = new InlineEditRequestLogContext(doc.id.uri, document.version, undefined);
				logContext.recordingBookmark = model.debugRecorder.createBookmark();
				void commands.executeCommand(reportFeedbackCommandId, { logContext });
			}));
		}));

		constructorTracer.returns();
	}
}

export const learnMoreCommandId = 'github.copilot.debug.inlineEdit.learnMore';

export const learnMoreLink = 'https://aka.ms/vscode-nes';

const clearCacheCommandId = 'github.copilot.debug.inlineEdit.clearCache';
const reportNotebookNESIssueCommandId = 'github.copilot.debug.inlineEdit.reportNotebookNESIssue';
